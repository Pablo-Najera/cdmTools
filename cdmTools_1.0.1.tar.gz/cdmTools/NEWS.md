# cdmTools 1.0.1
* Added - GNPC function to estimate attribute profiles
* Added - print methods for classes

# cdmTools 1.0.0
* CRAN release

# cdmTools 0.1.1
* Fixed - bug in `modelcompK` when a stop criterion is used and exploreK does not include K = 1
* Fixed - bug in `paK` when missing values are present in correlation matrix
* Fixed - bug in `modelcompK` when M2 statistic cannot be computed for a model

# cdmTools 0.1.0
* GitHub release
