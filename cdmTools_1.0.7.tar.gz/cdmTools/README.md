# cdmTools: Useful Tools for Cognitive Diagnosis Modeling
[![Project Status: Active – The project has reached a stable, usable state and is being actively developed.](https://www.repostatus.org/badges/latest/active.svg)](https://www.repostatus.org/#active)
[![CRAN\_Status\_Badge](http://www.r-pkg.org/badges/version/cdmTools?color=brightgreen)](https://cran.r-project.org/package=cdmTools)
[![](https://cranlogs.r-pkg.org/badges/cdmTools?color=blue)](https://cran.r-project.org/package=cdmTools)
[![](http://cranlogs.r-pkg.org/badges/grand-total/cdmTools?color=blue)](https://cran.r-project.org/package=cdmTools)

## How to cite this package
Nájera, P., Sorrel, M. A., & Abad, F. J. (2025). *cdmTools: Useful Tools for Cognitive Diagnosis Modeling*. R package version 1.0.6. https://cran.r-project.org/web/packages/cdmTools/.
## Features of the package
* R-DINA and R-DINO model estimation
* G-DINA model estimation for forced-choice items
* Attribute profile classification via the general nonparametric classification method (GNPC)
* Empirical Q-matrix estimation and validation
* Empirical dimensionality assessment of CDM data
* Corrected classification accuracy estimation via multiple imputation
* Model-based recursive partitioning via G-DINA trees
* Person fit evaluation
* Model identifiability check
* Useful functions for simulation studies involving CDM
## Installation
To install this package from source:
1. Windows users may need to install the [Rtools](https://cran.r-project.org/bin/windows/Rtools/) and include the checkbox option of installing Rtools to their path for easier command line usage. Mac users will have to download the necessary tools from the [Xcode](https://apps.apple.com/ca/app/xcode/id497799835?mt=12) and its related command line tools (found within Xcode's Preference Pane under Downloads/Components); most Linux distributions should already have up to date compilers (or if not they can be updated easily).
2. Install the `devtools` package (if necessary), and install the package from the Github source code.

```
#install.packages("devtools")
devtools::install_github("Pablo-Najera/cdmTools")
```

## Bug reports
Please report any bugs at https://github.com/Pablo-Najera/cdmTools/issues.
